<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class RegisterController extends Controller
{
    public function register(Request $request)
{
    $validator = Validator::make($request->all(), [
        'phone_number' => 'required|unique:users',
        'password' => 'required|min:6',
    ]);

    if ($validator->fails()) {
        return response()->json($validator->errors(), 422);
    }

    $user = new User();
    $user->phone_number = $request->phone_number;
    $user->password = bcrypt($request->password);
    $user->save();

    try {
        $token = auth()->attempt($request->only('phone_number', 'password'));
    } catch (\Exception $e) {
        return response()->json(['error' => 'could_not_create_token'], 500);
    }

    return response()->json([
        'token' => $token,
        'user' => auth()->user(),
    ], 201);
}
}
